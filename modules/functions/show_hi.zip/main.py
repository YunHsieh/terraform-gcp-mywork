def show_hi():
    return 'hi'